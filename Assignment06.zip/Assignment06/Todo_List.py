#Title =  Home Inventory Script
#Date: Feb. 17th. 2019
#Changelog David, Inception, Feb. 17th. 2019


#create a list
todolist = list()

class Menu:
    def __init__(self, todolist):
        self.todolist = todolist
    def displaychoices(self):
        #display menu of choices to the user
        print("1) Show current data  ")
        print("2) Add a new item  ")
        print("3) Remove an existing item  ")
        print("4) Save data to file  ")
        print("5) Exit Program  ")

    def showcurrentdata(self):
        i = 1
        print ("\nCurrent data")
        while i <= len(todolist):
            row = todolist[i-1]
            print(str(i) + ":" + row["task"] + "," + row["priority"])
            i = i + 1
        print("\n")

    def addnewitem(self):
        print("adding new item")
        task = input("Enter the task")
        priority = input("Enter the priority")
        d = {"task": task, "priority": priority}
        todolist.append(d)

    def removeexitingitem(self):
        menu.showcurrentdata()
        removeitem = input("Which item (enter the corresponding number) would you like to be removed")
        index = int(removeitem) - 1
        if index < 0 or  index > len(todolist) - 1:
            print('invalid entry')
            return
        del todolist[int(removeitem)-1]

    def savedatatofile(self):
        print("save data to file")
        file = open('ToDo.txt', 'w')
        for row in todolist:
            file.write(row["task"] + "," + row["priority"] + "\n")
        file.close()


def exitprogram():
    exit(0)


#load txt file
file = open("ToDo.txt", "r")
for line in file:
    line = line.strip()
    if len(line) == 0:
        continue
    entry = line.split(",")
    d = {"task": entry[0], "priority": entry[1]}
    todolist.append(d)

menu = Menu(todolist)

while True:
    menu.displaychoices()
    #input the users choice
    choice = input("\nEnter 1-5: ")
    #todo validate entries 1-5


    #process the users choice

    # show current data
    if choice == "1":
        menu.showcurrentdata()
    #Adda new item
    elif choice == "2":
        menu.addnewitem()
    #remove existing item
    elif choice == "3":
        menu.removeexitingitem()
    # save data to file
    elif choice == "4":
        menu.savedatatofile()
    # exit current data
    elif choice == "5":
        exitprogram()
    else:

        print("unkown option")



