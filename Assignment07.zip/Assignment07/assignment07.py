#Title =  Home Inventory Script with Exception Handling and Pickling
#Date: Feb. 24. 2019
#Changelog David, Inception, Feb. 24th. 2019

#gain access to pickle library
import pickle

#create an empty list
todolist = list()

def displaychoices():
    #display menu of choices to the user
    print("1) Show current data  ")
    print("2) Add a new item  ")
    print("3) Remove an existing item  ")
    print("4) Save data to file  ")
    print("5) Exit Program  ")

def showcurrentdata():
    i = 1
    print ("\nCurrent data")
    while i <= len(todolist):
        row = todolist[i-1]
        print(str(i) + ":" + row["task"] + ", " + row["priority"] + ", " + row["time"])
        i = i + 1
    print("\n")


def addnewitem():
    print("adding new item")
    task = input("Enter the task")
    priority = input("Enter the priority")
    time = input("Enter the time required in minutes")
    try:
        timeint = int(time)
    except ValueError:
        #report the error and swallow the exception by returning from sub routine
        print(x + " is not an integer")
        return("")
    d = {"task": task, "priority": priority, "time": time}
    todolist.append(d)

def removeexitingitem():
    showcurrentdata()
    removeitem = input("Which item (enter the corresponding number) would you like to be removed")
    index = int(removeitem) - 1
    if index < 0 or  index > len(todolist) - 1:
        print('invalid entry')
        return
    del todolist[int(removeitem)-1]

def savedatatofile():
    print("save data to file")
    #open the file in binary mode
    file = open('ToDo.dat', 'wb')
    #use pickle to write object
    pickle.dump(11111111111111111todolist, file)
    file.close()


def exitprogram():
    exit(0)


#load txt file
try:
    #open the file for reading in binary mode
    file = open("todo.dat", "rb")
    #load the object from the file into the to do list
    todolist = pickle.load(file)
except Exception as e:
    print("file does not exist")

while True:
    displaychoices()
    #input the users choice
    choice = input("\nEnter 1-5: ")
    #todo validate entries 1-5


    #process the users choice

    # show current data
    if choice == "1":
        showcurrentdata()
    #Adda new item
    elif choice == "2":
        addnewitem()
    #remove existing item
    elif choice == "3":
        removeexitingitem()
    # save data to file
    elif choice == "4":
        savedatatofile()
    # exit current data
    elif choice == "5":
        exitprogram()
    else:
        print("unknown option")



